﻿/*

Copyright (c) 2003-2011, CKSource - Frederico Knabben. All rights reserved.

For licensing, see LICENSE.html or http://ckeditor.com/license

*/



CKEDITOR.editorConfig = function( config )

{


config.filebrowserBrowseUrl = 'https://siei.industry.gov.iq/public/ckfinder/ckfinder.html';

config.filebrowserImageBrowseUrl = 'https://siei.industry.gov.iq/public/ckfinder/ckfinder.html?type=Images';

config.filebrowserFlashBrowseUrl = 'https://siei.industry.gov.iq/public/ckfinder/ckfinder.html?type=Flash';

config.filebrowserUploadUrl = 'https://siei.industry.gov.iq/public/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files';

config.filebrowserImageUploadUrl = 'https://siei.industry.gov.iq/public/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images';

config.filebrowserFlashUploadUrl = 'https://siei.industry.gov.iq/public/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash';


};
